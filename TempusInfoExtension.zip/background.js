// background.js

chrome.webRequest.onBeforeRequest.addListener(
    function(details) {
      // Check if it's a GET request
      if (details.method === "GET") {
        // Extract relevant data from the request
        var interceptedData = details.url; // This is just an example, replace it with your actual intercepted data
        // Send a message to content script to inject HTML
        chrome.tabs.query({ active: true, currentWindow: true }, function(tabs) {
          chrome.tabs.sendMessage(tabs[0].id, { action: "injectHTML", data: interceptedData });
        });
      }
    },
    { urls: ["<all_urls>"] },
    ["blocking"]
  );
  