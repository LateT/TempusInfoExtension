// content.js

// Function to add HTML code to the page
function addHTMLToPage(data) {
    // Create a new element
    var div = document.createElement("div");
    // Set its inner HTML to the data you want to inject
    div.innerHTML = "<p>This is injected content based on intercepted data: " + data + "</p>";
    // Append the element to the body or any other relevant part of the DOM
    document.body.appendChild(div);
  }
  
  // Listen for messages from the background script
  chrome.runtime.onMessage.addListener(function(message, sender, sendResponse) {
    // Check if the message is about injecting HTML
    if (message.action === "injectHTML") {
      // Call the function to add HTML to the page
      addHTMLToPage(message.data);
    }
  });
  